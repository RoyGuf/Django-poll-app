from django.apps import AppConfig


class pollsConfig(AppConfig):
    name = 'polls'
